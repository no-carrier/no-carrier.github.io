--------------------------------------------------------------
scrollNES 0.1 by NO CARRIER & Batsly Adams
8bitpeoples Research & Development - http://www.8bitpeoples.com
--------------------------------------------------------------

Copyright 2010 Don Miller / Andrew Reitano
For more information, visit: http://www.no-carrier.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

--------------------------------------------------------------
INCLUDED FILES
--------------------------------------------------------------

asm6.exe       - ASM6 assembler by loopy - http://home.comcast.net/~olimar/NES/
charmap.bin    - Character set - output of Excel file
compile.bat    - Batch file used to compile ROM
scroll.asm     - Source code
scroll.chr     - CHR file
gpl.txt        - GNU General Public License
nestext.xls    - Excel file containing character set
readme.nes     - Greeting from NO CARRIER & Batsly Adams
readme.txt     - You're reading it

--------------------------------------------------------------
RECOMMENDED SOFTWARE
--------------------------------------------------------------

YY-CHR   - Tile editor  - http://www.briansemu.com/yymarioed/
Context  - Text editor  - http://www.contexteditor.org/
Nestopia - NES emulator - http://nestopia.sourceforge.net/

--------------------------------------------------------------
RECOMMENDED HARDWARE
--------------------------------------------------------------

PowerPak - NES flash cart         - http://www.retrousb.com
ReproPak - NES reproduction board - http://www.retrousb.com

--------------------------------------------------------------
USAGE
--------------------------------------------------------------

scrollNES is a tool to display scrolling text on the NES. The large font is created dynamically by reading character data from a single file and representing each bit as a tile in the background. The ROM has been tested to work in Nestopia, FCEUX, and actual NES hardware via the PowerPak.

Controls:

B        - Toggle horizontal scroll speed
Select   - Toggle vertical size (1x / 2x)
Start    - Change character style

*** Note that the changes will not take effect until the beginning of the next message! ***

The font set consists of 90 8x8 characters (ASCII 32-122). An excel file (nestext.xls) has been included for easy editing, simply place a 1 in the character grid to paint on a bit. You should see the color change in both the original and transposed character. The code needed to represent the characters is automatically generated on the rightmost column. When you're satisfied with all of the changes made you'll need to export the updated character set. Select the entire column with the assembly directives (.byte $00, $01, ..) and copy and paste them into charmap.txt, making sure to overwrite all of the previous code.

To edit the message, simply open scroll.asm and find the label "string". Type your text within the quotes, save, and compile.

string: .db "Place message here",$FF

The byte $FF is the terminating character, it's used to signal the end of the string. If you need to adjust the time before the next message loops around, add a few spaces to the end of your message.

Enjoy!

--------------------------------------------------------------
TECHNICAL NOTES
--------------------------------------------------------------
- Since we are writing these characters vertically, they needed to be transposed somehow (by column rather than by row). We chose to do this in excel ahead of time to simplify code avoid wasting cycles on the NES.
- The gradient bars on the sides to simulate a fade-in exist as several sprites with transparency. They can be re-arranged by changing the tile numbers in sprite section or directly edited in YY-CHR.
- The character styles can be edited by changing the tiles in YY-CHR. They are arranged in pairs that represent both the 0 and 1 bit.

--------------------------------------------------------------
VERSION HISTORY
--------------------------------------------------------------

0.1 - 01.15.2010 - Initial release