--------------------------------------------------------------
9999-in-1 0.2 by NO CARRIER
8bitpeoples Research & Development - http://www.8bitpeoples.com
--------------------------------------------------------------

Copyright 2010 Don Miller
For more information, visit: http://www.no-carrier.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

--------------------------------------------------------------
INCLUDED FILES
--------------------------------------------------------------
0.chr          - renamed version of geo.chr by Alex Mauer
9999-in-1.asm  - Source code for 9999-in-1
asm6.exe       - ASM6 assembler by loopy - http://home.comcast.net/~olimar/NES/
compile.bat    - Batch file to compile 9999-in-1
gpl.txt        - GNU General Public License
readme.txt     - You're reading it
screen.nam     - Default menu screen

--------------------------------------------------------------
FILES YOU'LL NEED IN THE SAME FOLDER
--------------------------------------------------------------

1.prg          - the PRG of your first ROM
1.chr          - the CHR of your first ROM
2.prg          - the PRG of your second ROM
2.chr          - the CHR of your second ROM
3.prg          - the PRG of your third ROM
3.chr          - the CHR of your third ROM

--------------------------------------------------------------
RECOMMENDED SOFTWARE
--------------------------------------------------------------

HexEdit  - Hex editor   - http://www.mitec.cz/hex.html
YY-CHR   - Tile editor  - http://www.briansemu.com/yymarioed/
Context  - Text editor  - http://www.contexteditor.org/
Nestopia - NES emulator - http://nestopia.sourceforge.net/
cajoNES  - ROM utility  - http://www.zophar.net/utilities/nesutil/cajones.html

--------------------------------------------------------------
RECOMMENDED HARDWARE
--------------------------------------------------------------

PowerPak - NES flash cart         - http://www.retrousb.com
ReproPak - NES reproduction board - http://www.retrousb.com

--------------------------------------------------------------
USAGE
--------------------------------------------------------------

9999-in-1 is a multicart ROM for the NES. It only supports 4
32k PRG NROM or equivalent games, with 8k of CHR for each. I'm
assuming you know a little about how NES games work, but not
much about bankswitching. If you fit that description, this
software will be useful.

When compiled, the ROM created is GNROM, or mapper 66. The
total PRG size will be 128k, or four 32k banks. The total CHR
size will be 32k, or four 8k banks. This is perfect for NROM-256
games, as they are exactly that size (40k combined).

To prepare your ROM's, make sure that each can be split into
exactly 32k for the PRG and 8k for the CHR. The ROM size should
be 40k in size, but you can check the exact info in an emulator,
like Nestopia (linked above). In Nestopia, go to View > Image
Info. It will tell you the size of the PRG and CHR. To split
the ROM, you can use a hex editor, like HexEdit (linked above).
First, you'll need to remove the header from the ROM that is
only used by emulators. That will be the first 16 bytes of the
ROM. Next, split the file into two pieces, the first part being
32k, and the second being 8k. The first part will be the PRG,
and the second will be the CHR. There are tools to automate this
process, cajoNES being one of them. You can find cajoNES linked
above. Once the ROM is loaded in cajoNES, you can split it into
PRM/PRG/CHR. Don't worry about the PRM file, its not needed.

Do this three times, and name each pair of files 0, 1, or 2 .PRG
and .CHR (like it says above, under "FILES YOU'LL NEED IN THE SAME
FOLDER"). Take a look at the bottom of 9999-in-1.asm. You can see
that it complies 9999-in-1.asm to be the first PRG (0.prg). Next,
it combines it with 1.prg, 2.prg, and 3.prg. Then it appends all
of the CHR files.

If all goes well, you'll have 4 ROM's in 1 - the menu, and three
others you chose. Of course the menu can be a ROM in itself, if
you'd like. Right now, its just a waste of 32k.

When you run the compiled ROM, you can press up or down to choose
a ROM, and start to run it. You'll need to perform a hard reset
to get back to the menu, as a soft reset will only reset the game
to the current ROM. If you want to edit the menu, you'll need to
get a nametable editor and modify screen.nam. Look at galleryNES
on my site for all you'll need for that.

The only potential problem I could see is if you try to combine
games that have 16k PRG, rather than 32k. In that case, just pad
the file using a hex editor, or more simply: just modify the
compile.bat file to append an extra copy to make sure it all
lines up to 32k.

For details on how the bankswitching works, take a look at the
commented code. The idea is simple, though: a small bankswitch
routine is copied to RAM, and when you choose a bank, that code
is executed and the PRG and CHR switch. There is a little trick
built in to avoid bus conflicts, and thats it! Again, look at
the code for more information.

Good luck and enjoy!

--------------------------------------------------------------
VERSION HISTORY
--------------------------------------------------------------

0.2 - 06.10.2010 - Source update & new title screen
0.1 - 06.01.2010 - Initial release