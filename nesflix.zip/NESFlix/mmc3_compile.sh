./asm6 nesflix_mmc3.asm temp.bin
cat temp.bin mmc3.chr > nesflix_mmc3.nes
rm temp.bin
