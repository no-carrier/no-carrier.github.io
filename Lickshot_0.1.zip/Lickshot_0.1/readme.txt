--------------------------------------------------------------
Lickshot 0.1 by NO CARRIER
8bitpeoples Research & Development - http://www.8bitpeoples.com
--------------------------------------------------------------

Copyright 2009 Don Miller
For more information, visit: http://www.no-carrier.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

--------------------------------------------------------------
INCLUDED FILES
--------------------------------------------------------------

asm6.exe      - ASM6 assembler by loopy - http://home.comcast.net/~olimar/NES/
compile.bat   - Batch file to compile Lickshot
gpl.txt       - GNU General Public License
lickshot.asm  - Source code for Lickshot
lickshot.chr  - CHR file (tile data)
lickshot.nam  - Screen data
readme.txt    - You're reading it
samp_con.bat  - Batch file to convert .WAV files into .DMC files

--------------------------------------------------------------
INCLUDED SAMPLE FILES
--------------------------------------------------------------

horn.dmc                - air horn sample
laster.dmc              - laser gun sample
TMNT3_Hey.dmc           - TMNT 3 - "Hey" vocal sample
TopGunDF_BeatThemUp.dmc - Top Gun DF - "Beat Them Up" vocal sample

--------------------------------------------------------------
RECOMMENDED SOFTWARE
--------------------------------------------------------------

Context  - Text editor  - http://www.contexteditor.org/
Nestopia - NES emulator - http://nestopia.sourceforge.net/
DMC Converter v0.05 - http://www.geocities.co.jp/Playtown-Denei/9628/

--------------------------------------------------------------
RECOMMENDED HARDWARE
--------------------------------------------------------------

PowerPak - NES flash cart         - http://www.retrousb.com 
ReproPak - NES reproduction board - http://www.retrousb.com

--------------------------------------------------------------
USAGE
--------------------------------------------------------------

Lickshot is an NES ROM image. It will work in Nestopia (see above)
and other NES emulators. It has also been tested on NTSC NES hardware
and a Subor famiclone using both EEPROM development carts and the
RetroZone PowerPak.

Controls are as follows:

UP / DOWN - pitch samples up or down
SELECT    - play sample loaded at $C000
START     - play sample loaded at $D000
B         - play sample loaded at $E000
A         - play sample loaded at $F000

--------------------------------------------------------------
ADDING YOUR OWN SAMPLES FROM .WAV
--------------------------------------------------------------

Download "DMC Converter" from the address listed above. Uncompress
it into your Lickshot folder/directory.

Place .WAV samples to be coverted in your Lickshot folder, in the
following format: 44,100 Hz, 16 Bit, Mono, PCM

Then click on "samp_con.bat" - this will begin the conversion
process. In the window that opens, write down the information after
"Len-reg value" for each of the samples that you convert. It will
look something like this: Len-reg value: 167 ($A7) 

Now, you need to edit the Lickshot source code to use your new
samples. I recommend Context with the 6502 highlighter for easy
source code manipulation.

Open up the source code and go to line 326. Here you will see the
space for the four samples to be loaded. Each sample you load must
not exceed 4k (4,096 bytes) in DMC format. After each ".incbin"
statement, put your DMC file name in parenthesis.

Finally, go up to line 228. This is where the first sample is
triggered by the SELECT button. You can see which samples at the
bottom link to which buttons above under "USAGE" in this document.

Go down to line 239. This is where you will input the first value
from the "Len-reg value" that you wrote down earlier. You have to
put in the value in parenthesis (the hex value) that starts with a "$". 

Then change the length values in lines: 257, 275, and 293.

You shouldn't encounter any problems if your samples don't exceed
4k, you correctly included them at the bottom, and correctly
entered their lengths above.

--------------------------------------------------------------
ADDING YOUR OWN SAMPLES FROM .DMC
--------------------------------------------------------------

One last note to those that already have their DMC samples, and
did not convert them from .WAV's:

Look at line 241 in the source code. Here you see a way to figure
out the length values manually. First, find the exact number of bytes
for your sample. Then, convert that to binary.

Let's say your sample is 1,025 bytes (same as TMNT3_Hey.dmc).

In binary, that is: 10011010010

Next, paste your number below:

10000000001 (example from above)
LLLLLLLL0001

Now, line up the numbers. Since there is a space, add a zero to the
left:

010000000001 (example from above, with zero on left added)
LLLLLLLL0001

Now, you only need the numbers that match up with the "L's":

01000000 0001 (example from above, with zero on left added)
LLLLLLLL 0001

That means we need: 01000000 - converted to hex: $40

Use $40 in the length counter. Yay!

--------------------------------------------------------------
VERSION HISTORY
--------------------------------------------------------------

0.1 - 09.04.2009 - Initial release